import Card from "./Components/Card"

function App() {

  return (
    <>
      <div>
        <h1>Seja bem vindo!</h1>
        
        <Card />
      </div>
    </>
  )
}

export default App
