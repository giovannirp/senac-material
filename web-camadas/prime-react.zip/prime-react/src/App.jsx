import "./app.css";
import Router from "./Router";

function App() {

  return (
    <>
      <div>
        <h1 className="text-principal">Seja bem vindo!</h1>
        <Router />
      </div>
    </>
  )
}

export default App
